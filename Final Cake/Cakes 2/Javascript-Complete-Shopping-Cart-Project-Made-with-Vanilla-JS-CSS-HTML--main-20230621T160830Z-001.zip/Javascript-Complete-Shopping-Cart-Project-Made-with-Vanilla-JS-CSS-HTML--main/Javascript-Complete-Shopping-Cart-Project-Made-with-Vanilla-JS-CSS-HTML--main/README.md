# Javascript-Complete-Shopping-Cart-Project-Made-with-Vanilla-JS-CSS-HTML-
This Projects features a lot of functions I will love developers to explore,  the functions ranges from the add items cart to 
having the added cart items on another page i.e the cart page is entirely another page, it is there not a single page shopping cart
project. On the items page or main web page once an item is added to cart, it can no longer be added to cart but the quantity can be 
increased from the cart page.  For neatnessness and simplicity an array was created to contain the each product information and
The cart logo increments the number of items in cart once another item is added to cart,  now concerning the cart page, I have added some
functionalities which includes incrementing or decrementing the quantity of each item, removing item from cart, as the quantity of an item
increases,  the total price increases, the unit total also increases and the no of item in cart logo also increases. 
If a user decides to shop more before purchasing he/she can decide to go back to the shopping page and also if he decides to clear everything  
from cart,  he can and lastly he can also use to purchase the button to display a thank you message and to clear the cart.  
Below is the breakdown of the functions of this project into list 

1. Multiple page functionality 
2. Addition of cart items using Javascript, this making the markup very neat
3.A single click to ad items to cart.
4. The same item cannot be re-added to cart once added
5. Local storage functionality, items in cart never disappears after refresing the page
6. Items remain in cart even after the browser is closed and re-opened again
7. Items quantity can be incremented and decremented in the cart page, as the increment or decrement takes place the unit total and total price also increase or decreases
8. Items can be completely removed from cart
9. A user can decide to go back to homepage from the cart page to continue shopping 
10. User or a customer can decide to clear cart with the cart button. 

Please Note: Included in this project a sidenav and a footer, which are not really part of the project, it was just added to ease stress for anyone who hastily needs a project they can work with without writing Lall of those from scratch.  
I have also included the zip file if you intend to download this project into your computer easily.
I am convinced you will enjoying using or exploring this project. 

  DISCLAIMER: PLEASE NOTE ALL THE IMAGES USED IN THIS PROJECT ARE NOT MINE, SOME OF THEM ARE DOWMLOADED FROM PIXABAY WEBSITE.  


![Screenshot (36)](https://user-images.githubusercontent.com/110282999/195982901-070f2b27-1f9e-407e-a007-6006c02b0b2d.png)
![Screenshot (40)](https://user-images.githubusercontent.com/110282999/195983091-750a4ec9-b980-471e-998a-2599f9c3a132.png)
![Screenshot (41)](https://user-images.githubusercontent.com/110282999/195983094-90ac667d-7479-4274-a21c-161aa37f6886.png)
![Screenshot (42)](https://user-images.githubusercontent.com/110282999/195983095-1e81d41d-48f1-4aeb-b649-96cf25d18e62.png)
![Screenshot (43)](https://user-images.githubusercontent.com/110282999/195983100-436161c4-8a5e-4ef5-84a9-426a83385f4b.png)
![Screenshot (44)](https://user-images.githubusercontent.com/110282999/195983102-d67e6ed8-ce31-4919-ae9b-96741cda5edb.png)
![Screenshot (37)](https://user-images.githubusercontent.com/110282999/195983103-8410fc9d-82fa-4c8b-898b-3cfac47846bc.png)
![Screenshot (45)](https://user-images.githubusercontent.com/110282999/195983175-f6ea6e55-3601-484f-8e7f-eedfacc82a0c.png)
![Screenshot (38)](https://user-images.githubusercontent.com/110282999/195983107-29bf23dd-f0d3-41b3-aa29-d8960431201a.png)


